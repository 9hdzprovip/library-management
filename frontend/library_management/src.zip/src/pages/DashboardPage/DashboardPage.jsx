import './DashboardPage.css';

function DashboardPage() {
  return (
    <section className="dashboard-page">
      <h1>Dashboard</h1>
      <p>Library management overview.</p>
    </section>
  );
}

export default DashboardPage;
