import UserTable from '../components/UserTable';
import '../styles/user.css';

function UserPage() {
  return (
    <section className="user-page stack">
      <div className="page-header">
        <div>
          <h1>Quản lý người dùng</h1>
          <p>Manage users and roles.</p>
        </div>
      </div>
      <UserTable users={[]} />
    </section>
  );
}

export default UserPage;
