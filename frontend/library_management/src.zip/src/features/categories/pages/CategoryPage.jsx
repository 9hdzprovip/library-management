import CategoryTable from '../components/CategoryTable';
import '../styles/category.css';

function CategoryPage() {
  return (
    <section className="category-page stack">
      <div className="page-header">
        <div>
          <h1>Quản lý danh mục</h1>
          <p>Manage book categories.</p>
        </div>
      </div>
      <CategoryTable categories={[]} />
    </section>
  );
}

export default CategoryPage;
