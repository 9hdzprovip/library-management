import { useCallback, useEffect, useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import AuthorTable from '../components/AuthorTable';
import AuthorForm from '../components/AuthorForm';
import Modal from '../../../components/common/Modal/Modal';
import Button from '../../../components/common/Button/Button';
import Input from '../../../components/common/Input/Input';
import * as authorApi from '../../../api/authorApi';
import '../styles/author.css';

function getErrorMessage(error, fallback) {
  return error?.message || fallback;
}

function sortById(data) {
  if (!Array.isArray(data)) {
    return [];
  }

  return [...data].sort((a, b) => Number(a.id) - Number(b.id));
}

function AuthorPage() {
  const role = (localStorage.getItem('role') || 'USER').toUpperCase();
  const isAdmin = role === 'ADMIN';

  const [authors, setAuthors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAuthor, setEditingAuthor] = useState(null);

  const loadAuthors = useCallback(async () => {
    try {
      setLoading(true);
      setError('');
      const data = await authorApi.getAll();
      setAuthors(sortById(data));
    } catch (err) {
      setError(getErrorMessage(err, 'Không thể tải danh sách tác giả.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAuthors();
  }, [loadAuthors]);

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return authors;
    return authors.filter((author) => author.name?.toLowerCase().includes(q));
  }, [authors, searchTerm]);

  function openAdd() {
    setError('');
    setSuccessMessage('');
    setEditingAuthor(null);
    setIsModalOpen(true);
  }

  function openEdit(author) {
    setError('');
    setSuccessMessage('');
    setEditingAuthor(author);
    setIsModalOpen(true);
  }

  function closeModal() {
    setIsModalOpen(false);
    setEditingAuthor(null);
  }

  async function handleSave(authorData) {
    try {
      setError('');

      if (editingAuthor) {
        const response = await authorApi.update(editingAuthor.id, authorData);
        setSuccessMessage(response?.message || 'Cập nhật tác giả thành công');

        if (response?.updated) {
          closeModal();
          await loadAuthors();
        }
      } else {
        await authorApi.create(authorData);
        setSuccessMessage('Thêm tác giả thành công');
        closeModal();
        await loadAuthors();
      }
    } catch (err) {
      setError(getErrorMessage(err, 'Không thể lưu thông tin tác giả.'));
    }
  }

  async function handleDelete(author) {
    const confirmed = window.confirm(`Bạn có chắc muốn xóa tác giả "${author.name}"?`);
    if (!confirmed) {
      return;
    }

    try {
      setError('');
      await authorApi.delete(author.id);
      await loadAuthors();
    } catch (err) {
      setError(getErrorMessage(err, 'Không thể xóa tác giả.'));
    }
  }

  return (
    <section className="author-page">
      <div className="page-header page-header--space">
        <div>
          <h1>{isAdmin ? 'Quản lý tác giả' : 'Danh sách tác giả'}</h1>
          <p>{isAdmin ? 'Danh sách và quản lý thông tin tác giả.' : 'Danh sách tác giả trong thư viện.'}</p>
        </div>

        {isAdmin && (
          <div className="page-actions">
            <Button onClick={openAdd} variant="primary">Thêm tác giả</Button>
          </div>
        )}
      </div>

      <div className="search-card">
        <Input
          icon={Search}
          placeholder="Tìm theo tên tác giả..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {successMessage && !isModalOpen && <p className="author-page__success">{successMessage}</p>}
      {error && !isModalOpen && <p className="author-page__error">{error}</p>}

      <AuthorTable
        authors={filtered}
        loading={loading}
        onEdit={openEdit}
        onDelete={handleDelete}
        isAdmin={isAdmin}
      />

      <Modal title={editingAuthor ? 'Sửa tác giả' : 'Thêm tác giả'} isOpen={isModalOpen} onClose={closeModal}>
        {successMessage && <p className="author-page__success author-page__success--modal">{successMessage}</p>}
        {error && <p className="author-page__error author-page__error--modal">{error}</p>}
        <AuthorForm initialData={editingAuthor} onCancel={closeModal} onSave={handleSave} />
      </Modal>
    </section>
  );
}

export default AuthorPage;
