package com.project2.library_management.dto.response;

import com.project2.library_management.enums.UserRole;

public class AuthResponse {

    private String message;
    private String token;
    private String username;
    private UserRole role;

    public AuthResponse() {
    }

    public AuthResponse(String message, String token, String username, UserRole role) {
        this.message = message;
        this.token = token;
        this.username = username;
        this.role = role;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }
}